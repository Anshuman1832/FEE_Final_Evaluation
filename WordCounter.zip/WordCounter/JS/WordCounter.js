
function countText() {
    const text = document.getElementById('input-textarea').value;
  
    const words = text.trim().split(/\s+/).filter(word => word.length > 0).length;
  
    const characters = text.length;

    const sentences = text.split(/[.!?]\s/).filter(sentence => sentence.length > 0).length;

    document.getElementById('word-count').textContent = words;
    document.getElementById('charac-count').textContent = characters;
    document.getElementById('sentence-count').textContent = sentences;
  }

  document.getElementById('input-textarea').addEventListener('input', countText);

  countText();
  